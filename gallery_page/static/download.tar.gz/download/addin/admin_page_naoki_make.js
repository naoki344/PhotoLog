/*後から作り直している部分の中核*/
function onload() {
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=onload",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					//スペースリストの追加
					target = document.getElementById("space_list");	
					target.innerHTML = addSpaceList(ret);
					//ページ一覧表示
					target = document.getElementById("page");	
					target.innerHTML = addPageList(ret);
                }
        	}
    });
	
}
function get_image_list(pg_id,cat_id){
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=get_image_list&pg_id="+pg_id+"&cat_id="+cat_id+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					//スペースリストの追加
					document.getElementById("image_list").innerHTML = drow_image_list(ret);
                }
        	}
    });

}
function drow_image_list(ret){
	html = "\n"+
'									<div class="">\n'+
'										<form class="custom" name="image_select_form" ACTION="ajax.cgi" METHOD="GET">\n';
	for(i=0; i < ret["data"]["img_ls"].length; i++){
		if (ret["data"]["img_ls"][i]["s"] == "1"){
			st = "CHECKED";
		}else{
			st = "";
		}
		html += "\n"+
'												<div style="display: inline-block;">\n'+
'													<label>\n'+
'													    <input class="location_checkbox" type="checkbox" name="test" value="'+ret["data"]["img_ls"][i]["i_n"]+'" '+st+'>\n'+
'													      <img class="thumbnail" src="./image/'+ret["data"]["pg_info"]["dir"]+'/thum_small/'+ret["data"]["img_ls"][i]["i_n"]+'" style="width;100px">\n'+
'													</label>\n'+
'												</div>\n';
	}
	html += "\n"+
'										</form>\n'+
'												<div class="large-13 columns right" style="margin-top:20px">\n'+
'													<button onClick="image_slcted(\'image_select_form\',\''+ret["data"]["pg_info"]["pi"]+'\',\''+ret["data"]["cat_id"]+'\');"  type="button" class="button highlight-dark round right"  >追加</button>\n'+
'												</div>\n'+
'										</div>\n';
	return html;
}
function image_slcted(form_name,pg_id,cat_id){
	var checkboxElements = document.forms[form_name];
	var unchecked_img ="";
	for (var i = 0, len = checkboxElements.length; i< len; i++){
			if(checkboxElements[i].checked){
			} else{
				unchecked_img += checkboxElements[i].value+",";
			}
	}
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=img_slcted&pg_id="+pg_id+"&cat_id="+cat_id+"&uncheck="+unchecked_img+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					//スペースリストの追加
					alert("OK");
                }
        	}
    });
}


function addPageList(ret){
	html = "";
	for(i=0; i < ret["all_pg"]["new"].length; i++){
		html += '<p><a href="#" onclick=\'AddPage("'+ret["all_pg"]["new"][i]+'");return false;\'>'+ret["all_pg"]["new"][i]+'</a></p>\n';
	}
	for (i=0; i < ret["all_pg"]["org"].length; i++){
		c = i +1;
		html += '\n'+
'						<!-- content2 -->\n'+
'								<fieldset>\n'+
'									<legend>('+c+') '+ret["all_pg"]["org"][i]["pg_n"]+'</legend>\n'+
'									<form class="custom" name="pg_form_'+i+'" ACTION="ajax.cgi" METHOD="GET">\n'+
'										<input  type="hidden" name="id" value="'+ret["all_pg"]["org"][i]["i"]+'"/>\n'+
'										<table class="content_box" >\n'+
'											<th>\n'+
'												<div class="photo" ><img src="'+ret["all_pg"]["org"][i]["pg_img"]+'"></div>\n'+
'											</th>\n'+
'											<td>\n'+
'												<div class="row">\n'+
'													<div class="large-4 columns">\n'+
'														<label>ページ名</label>\n'+
'														<input id="pg_n" type="text" name="pg_n" value="'+ret["all_pg"]["org"][i]["pg_n"]+'" placeholder="" required>\n'+
'													</div>\n'+
'													<div class="large-8 columns">\n'+
'														<div class="row collapse">\n'+
'															<label>管理ID</label>\n'+
'	                   										<div class="small-12 columns">\n'+
'	                   										   	<span class="prefix"><a href="photo.cgi?page='+ret["all_pg"]["org"][i]["i"]+'">フォルダ名&#061;'+ret["all_pg"]["org"][i]["pg_id"]+'</a></span>\n'+
'																<input  type="hidden" name="pg_id" value="'+ret["all_pg"]["org"][i]["pg_id"]+'"/>\n'+
'	                   										</div>\n'+
'														</div>\n'+
'													</div>\n'+
'													<div class="large-12 columns">\n'+
'														<label>画像リンク</label>\n'+
'														<input id="url_txt" type="text" name="pg_img" value="'+ret["all_pg"]["org"][i]["pg_img"]+'" placeholder="" required>\n'+
'													</div>\n'+
'												</div>					\n'+
'												<div class="row">			\n'+
'													<div class="large-12 columns">\n'+
'														<label>Memo</label>\n'+
'														<textarea type="text" name="memo" placeholder="右下にカーソルを合わせると自由に大きさを変えることができます。" required>'+ret["all_pg"]["org"][i]["m"]+'</textarea>\n'+
'													</div>\n'+
'												</div>\n'+
'												<div class="row">\n'+
'													<div class="small-2 columns">\n'+
'														<div id="checkbox_inline">\n'+
'																<label>Status</label>\n'+
'																<input class="tgl tgl-flip" id="pg_ch_'+i+'" name="pg_st" type="checkbox"  '+ret["all_pg"]["org"][i]["s"]+' >\n'+
'																<label class="tgl-btn" data-tg-off="OFF" data-tg-on="ON" for="pg_ch_'+i+'"></label>\n'+
'														</div>\n'+
'													</div>\n'+
'													<div class="small-4 columns left">\n'+
'														<label>コンテンツ個別管理</label>\n'+
'	                   									<span class="prefix"><a href="aaaa">'+ret["all_pg"]["org"][i]["pg_n"]+'</a></span>\n'+
'													</div>\n'+
'													<div class="small-4 columns right">\n'+
'															<button type="button" class="button  primary button round button tiny right" onClick="pageRenew(\'pg_form_'+i+'\');" >更新</button>\n'+
'													</div>					\n'+
'												</div>					\n'+
'											</td>\n'+
'										</table>\n'+
'									</form>\n'+
'								</fieldset>\n'+
'					<!-- content2 -->\n';
	}
	return html;
}
function pageRenew(form_name){
	var form = document.forms[form_name];
	pg_st = form.pg_st.checked;
	pg_name = form.pg_n.value;
	id = form.id.value;
	pg_memo = form.memo.value;
	pg_id = form.pg_id.value;
	pg_image = form.pg_img.value;
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=pg_renew&pg_n="+pg_name+"&id="+id+"&memo="+pg_memo+"&pg_id="+pg_id+"&s="+pg_st+"&pg_img="+pg_image+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					target = document.getElementById("page");	
					target.innerHTML = addPageList(ret);
                }
        	}
    });
}
function addSpaceList(ret){
	var html;
	var i;
	html = '\n'+
'					<!-- add content -->\n'+
'							<form name="_spaceform" action="" method="post" onChange="sp_slcted()">\n'+
'								<p>スペース：<br>\n'+
'									<select name="_space" id="space_select" style="height:40px">\n'+
'										<option  value="none">---</option>\n';
	for (i=0; i<ret["sp_ls"].length; i++){
		if (ret["sp_ls"][i]["s"] == "1"){
			html += ''+
'										<option  value="'+ret["sp_ls"][i]["si"]+'">'+ret["sp_ls"][i]["sn"]+'</option>\n';
		}else{
			html += ''+
'										<option  value="'+ret["sp_ls"][i]["si"]+'">'+ret["sp_ls"][i]["sn"]+'(OFF)</option>\n';
		}
	}
	html += '\n'+
'										<option  value="add">追加</option>\n'+
'									</select>\n'+
'								</p>\n'+
'							</form>\n'+
'					<!-- /add content -->\n';
	return html;	

}
function sp_slcted(){
	var html;
	var i;
	obj = document._spaceform._space;
	index = obj.selectedIndex;
	sp_id = obj.options[index].value;
	sp_name = obj.options[index].innerHTML;
	if( sp_id == "none") {
		document.getElementById("page_list").innerHTML = " <h6>スペースとカテゴリーを選択して下さい</h6>";	
		document.getElementById("category_list").innerHTML = "";	
		document.getElementById("category").innerHTML ="";	
		document.getElementById("space").innerHTML ="";	
	}else if (sp_id == "add"){
		document.getElementById("category_list").innerHTML = "";	
		document.getElementById("category").innerHTML ="";	
		document.getElementById("page_list").innerHTML = " <h6>スペースとカテゴリーを選択して下さい</h6>";	
		document.getElementById("space").innerHTML = drow_add_space();
	}else{
		document.getElementById("space").innerHTML ="";	
		$.ajax({
    	        url: "ajax.cgi",
    	        type: "GET",
    	        cache: false,
    	        async: false,
    	        data: "mode=sp_slcted&sp_i="+sp_id+"",
    	        success: function(ret){
    	            if(ret["ret"] == 'OK'){
						document.getElementById("space").innerHTML = drow_space_content(ret["sp_info"]["i"],ret["sp_info"]["sn"],ret["sp_info"]["si"],ret["sp_info"]["img"],ret["sp_info"]["s"],ret["sp_info"]["m"]);	
						document.getElementById("category_list").innerHTML = drow_category_list(ret);
    	            }
    	    	}
    	});
	}
}
function drow_category_list(ret){
	html = '\n'+
'						<!-- add category list -->\n'+
'								<form name="_categoryform" action="" method="post" onChange="cat_slcted()">\n'+
'									<input  type=\"hidden\" name=\"sp_name\" value=\"'+sp_name+'\"/>\n'+
'									<input  type=\"hidden\" name=\"sp_id\" value=\"'+sp_id+'\"/>\n'+
'									<p>カテゴリー：<br>\n'+
'										<select name="_category" id="category_select" style="height:40px">\n'+
'											<option  value="none">---</option>\n';
						for (i=0; i<ret["cat_ls"].length; i++){
							if (ret["cat_ls"][i]["s"] == "1"){	
								html += ''+
'											<option  value="'+ret["cat_ls"][i]["ci"]+'">'+ret["cat_ls"][i]["cn"]+'</option>\n';
							} else {
								html += ''+
'											<option  value="'+ret["cat_ls"][i]["ci"]+'">'+ret["cat_ls"][i]["cn"]+'(OFF)</option>\n';

							}
						}
						html += '\n'+
'											<option  value="add">追加</option>\n';
'										</select>\n'+
'									</p>\n'+
'								</form>\n'+
'						<!-- /add category list -->\n';
return html;
}
function cat_slcted(){
	var html = "";
	obj = document._categoryform._category;
	index = obj.selectedIndex;
	cat_id = obj.options[index].value;
	cat_name = obj.options[index].innerHTML;
	var form = document.forms._categoryform;
	sp_name = form.sp_name.value;
	sp_id = form.sp_id.value;
	if (cat_id == "none"){
		document.getElementById("category").innerHTML ="";	
		document.getElementById("page_list").innerHTML = " <h6>スペースとカテゴリーを選択して下さい</h6>";	
	} else{
		$.ajax({
    	        url: "ajax.cgi",
    	        type: "GET",
    	        cache: false,
    	        async: false,
    	        data: "mode=cat_slcted&sp_i="+sp_id+"&cat_i="+cat_id+"",
    	        success: function(ret){
    	            if(ret["ret"] == 'OK'){
						if (cat_id == "add") {
							document.getElementById("category").innerHTML = drow_add_category(sp_id);
							document.getElementById("page_list").innerHTML = drow_page_list(ret);
						} else {
							document.getElementById("page_list").innerHTML = drow_page_list(ret);
							document.getElementById("category").innerHTML = drow_category_content(ret);
						}
    	            }
    	    	}
    	});
	}
}
function drow_category_content(ret){
	if (ret["cat_info"]["s"] == "1"){
		st = "CHECKED";
	} else{
		st = "";
	}
	html_addcat = '\n'+
'					<!-- content2 -->\n'+
'							<fieldset>\n'+
'								<legend>'+ret["cat_info"]["cn"]+'</legend>\n'+
'								<form class=\"custom\" ACTION=\"ajax.cgi\" name="cat_renew_form" METHOD=\"GET\">\n'+
'									<input  type=\"hidden\" name=\"mode\" value=\"cat_renew\"/>\n'+
'									<input  type=\"hidden\" name=\"sp_id\" value=\"'+ret["cat_info"]["si"]+'\"/>\n'+
'									<input  type=\"hidden\" name=\"cat_id\" value=\"'+ret["cat_info"]["i"]+'\"/>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"large-4 columns\">\n'+
'											<label>カテゴリ名</label>\n'+
'											<input id=\"url_name\" type=\"text\" name=\"cat_n\" value=\"'+ret["cat_info"]["cn"]+'\" placeholder=\"表示名を入力\" required>\n'+
'										</div>\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>画像リンク</label>\n'+
'											<input id=\"url_img\" type=\"text\" name=\"cat_img\" value=\"'+ret["cat_info"]["img"]+'\" placeholder=\"画像のURLを入力\" required>\n'+
'										</div>\n'+
'									</div>					\n'+
'									<div class=\"row\">			\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>Memo</label>\n'+
'											<textarea type=\"text\" name=\"memo\"  placeholder=\"右下にカーソルを合わせると自由に大きさを変えることができます。\" required>'+ret["cat_info"]["m"]+'</textarea>\n'+
'										</div>\n'+
'									</div>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"small-2 columns\">\n'+
'											<div id=\"checkbox_inline\">\n'+
'													<label>Status</label>\n'+
'													<input class=\"tgl tgl-flip\" id=\"new\" name=\"st\" type=\"checkbox\" '+st+'>\n'+
'													<label class=\"tgl-btn\" data-tg-off=\"OFF\" data-tg-on=\"ON\" for=\"new\"></label>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"large-2 columns right\">\n'+
'												<button type="button" class="button highlight-dark button round button tiny right" onClick="renew_category(\'cat_renew_form\');" >更新</button>\n'+
'										</div>					\n'+
'									</div>					\n'+
'								</form>\n'+
'							</fieldset>\n'+
'					<!-- content2 -->\n';
return html_addcat;
}
function renew_category(form_name){
	var form = document.forms[form_name];
	sp_id = form.sp_id.value;
	cat_id = form.cat_id.value;
	cat_n = form.cat_n.value;
	cat_image = form.cat_img.value;
	cat_memo = form.memo.value;
	cat_s = form.st.checked;

	var checkboxElements = document.forms['pg_select_form'];
	var id ="";
	for (var i = 0, len = checkboxElements.length; i< len; i++){
			if(checkboxElements[i].checked){
				//ページ一覧の中身が１つの場合要素へのアクセスができなる
				id += checkboxElements[i].value+",";
			}
	}
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=cat_renew&cat_id="+cat_id+"&sp_id="+sp_id+"&cat_n="+cat_n+"&memo="+cat_memo+"&s="+cat_s+"&cat_img="+cat_image+"&slct_id="+id+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					alert("更新しました");
					//ページ一覧表示
					document.getElementById("space").innerHTML ="";	
					document.getElementById("space_list").innerHTML = addSpaceList(ret);
					document.getElementById("category_list").innerHTML ="";	
					document.getElementById("category").innerHTML ="";	
					document.getElementById("page_list").innerHTML = " <h6>スペースとカテゴリーを選択して下さい</h6>";	
                }
        	}
    });


}
function drow_page_list(ret){
	var html="";
	var i;
	html += '\n'+
'									<form class=\"custom\" ACTION=\"ajax.cgi\" name="pg_select_form" METHOD=\"GET\">\n'+
'										<table class="pg_check" style="background-color:transparent;">\n';
	for (i=0;i<ret["pg_ls"].length; i++){
		if ( ret["pg_ls"][i]["pg_st"] == "0"){
			pg_status = "(OFF)";
		}else{
			pg_status = "";
		}
		if( ret["pg_ls"][i]["s"] == '1'){
			html += '\n'+
'											<tr style="background-color:transparent;">\n'+
'											<td style="margin:0px;padding:3px 5px 3px 0px;" >\n'+
'												<label style="width:100%;">\n'+
'													<input  class="checkbox04-input" name="pg_select" id="select_pg_'+i+'" value="'+ret["pg_ls"][i]["pi"]+'" type="checkbox" CHECKED/>\n'+
'													<span class="checkbox04-parts" style="width:100%;margin:0;" >'+ret["pg_ls"][i]["pn"]+''+pg_status+'</span>\n'+
'												</label>\n'+
'											</td>\n'+
'											<td style="margin:0px;padding:3px 5px 3px 0px;" >\n'+
'												<a href="./page_to_image.cgi?pg_id='+ret["pg_ls"][i]["pi"]+'&cat_id='+ret["cat_info"]["i"]+'" class="button secondary tiny radius" value="PickUP" style="width:100%;height:100%;margin:0;">PickUP</a>\n'+
'											</td>\n'+
'											</tr>\n';
		}else{
			html += '\n'+
'											<tr style="background-color:transparent;">\n'+
'											<td style="margin:0px;padding:3px 5px 3px 0px;" >\n'+
'												<label style="width:100%;">\n'+
'													<input  class="checkbox04-input" name="pg_select" id="select_pg_'+i+'" value="'+ret["pg_ls"][i]["pi"]+'" type="checkbox"/>\n'+
'													<span class="checkbox04-parts" style="width:100%;margin:0;" >'+ret["pg_ls"][i]["pn"]+''+pg_status+'</span>\n'+
'												</label>\n'+
'											</td>\n'+
'											<td style="margin:0px;padding:3px 5px 3px 0px;" >\n'+
'												<!--button type="button" class="button secondary tiny radius" style="width:100%;height:100%;margin:0;">PickUp</button-->\n'+
'												<a href="./page_to_image.cgi?pg_id='+ret["pg_ls"][i]["pi"]+'&cat_id='+ret["cat_info"]["i"]+'" class="button secondary tiny radius" value="PickUP" style="width:100%;height:100%;margin:0;">PickUP</a>\n'+
'											</td>\n'+
'											</tr>\n';
		}
	}
	html += '\n'+
'										<table>\n'+
'									</form>\n';
	return html;
}
/*  / 後から作り直している部分の中核*/
function drow_add_space(){
	html_addsp = '\n'+
'					<!-- content2 -->\n'+
'							<fieldset>\n'+
'								<legend>新規(スペース)</legend>\n'+
'								<form class=\"custom\" ACTION=\"ajax.cgi\" name="sp_create_form" METHOD=\"GET\">\n'+
'									<input  type=\"hidden\" name=\"mode\" value=\"sp_new\"/>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"large-4 columns\">\n'+
'											<label>スペース名</label>\n'+
'											<input id=\"url_name\" type=\"text\" name=\"sp_n\" value=\"\" placeholder=\"表示名を入力\" required>\n'+
'										</div>\n'+
'										<div class=\"large-8 columns\">\n'+
'											<div class=\"row collapse\">\n'+
'												<label>管理ID</label>\n'+
'                   								<div class=\"small-8 columns\">\n'+
'                   								   <span class=\"prefix\">top.cgi?space&#061;</span>\n'+
'                   								</div>\n'+
'												<div class=\"small-4 columns\">\n'+
'													<input id=\"url_txt\" type=\"text\" name=\"sp_i\" value=\"\" placeholder=\"英数字のみ\" required>\n'+
'												</div>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>画像リンク</label>\n'+
'											<input id=\"url_img\" type=\"text\" name=\"sp_img\" value=\"\" placeholder=\"画像のURLを入力\" required>\n'+
'										</div>\n'+
'									</div>					\n'+
'									<div class=\"row\">			\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>Memo</label>\n'+
'											<textarea type=\"text\" name=\"memo\"  placeholder=\"右下にカーソルを合わせると自由に大きさを変えることができます。\" required></textarea>\n'+
'										</div>\n'+
'									</div>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"small-2 columns\">\n'+
'											<div id=\"checkbox_inline\">\n'+
'													<label>Status</label>\n'+
'													<input class=\"tgl tgl-flip\" id=\"new\" name=\"st\" type=\"checkbox\" >\n'+
'													<label class=\"tgl-btn\" data-tg-off=\"OFF\" data-tg-on=\"ON\" for=\"new\"></label>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"small-4 columns right\">\n'+
'														<button type="button" class="button highlight-dark button round button tiny right" onClick="create_space(\'sp_create_form\');" >更新</button>\n'+
'										</div>					\n'+
'									</div>					\n'+
'								</form>\n'+
'							</fieldset>\n'+
'					<!-- content2 -->\n';
return html_addsp;
}
function create_space(form_name){
	var form = document.forms[form_name];
	sp_name = form.sp_n.value;
	sp_id = form.sp_i.value;
	sp_image = form.sp_img.value;
	sp_memo = form.memo.value;
	sp_s = form.st.checked;
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=sp_new&sp_n="+sp_name+"&sp_id="+sp_id+"&memo="+sp_memo+"&s="+sp_s+"&sp_img="+sp_image+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					alert("追加しました");
					//ページ一覧表示
					document.getElementById("space").innerHTML ="";	
					target = document.getElementById("space_list");	
					target.innerHTML = addSpaceList(ret);
                }
        	}
    });


}
function drow_space_content(id,name,k_id,img,s,memo){
	if(s == "1"){
		var st = "CHECKED"
	}
	html = '\n'+
'					<!-- content2 -->\n'+
'							<fieldset>\n'+
'								<legend>'+name+' (<a href="http://nao344.xyz/photo_box/top.cgi?space='+k_id+'">Go To Page</a>)</legend>\n'+
'								<form class="custom" name="sp_form_'+id+'" ACTION="ajax.cgi" METHOD="GET">\n'+
'									<input  type="hidden" name="id" value="'+id+'"/>\n'+
'									<div class="row">\n'+
'										<table class="content_box" >\n'+
'											<th>\n'+
'												<div class="photo" ><img src="'+img+'"></div>\n'+
'											</th>\n'+
'											<td>\n'+
'												<div class="large-12 columns">\n'+
'													<label>スペース名</label>\n'+
'													<input id="url_txt" type="text" name="sp_n" value="'+name+'" placeholder="" required>\n'+
'												</div>\n'+
'												<div class="large-12 columns">\n'+
'													<div class="row collapse">\n'+
'														<label>管理ID</label>\n'+
'                   										<div class="small-8 columns">\n'+
'                   										   <span class="prefix">/photo_box/top.cgi?space&#061;</span>\n'+
'                   										</div>\n'+
'														<div class="small-4 columns">\n'+
'															<input id="url_txt" type="text" name="sp_i" value="'+k_id+'" placeholder="" required>\n'+
'														</div>\n'+
'													</div>\n'+
'												</div>\n'+
'											</td>\n'+
'										</table>\n'+
'												<div class="large-12 columns">\n'+
'													<label>画像リンク</label>\n'+
'													<input id="url_txt" type="text" name="sp_img" value="'+img+'" placeholder="">\n'+
'												</div>\n'+
'											</div>					\n'+
'											<div class="row">			\n'+
'												<div class="large-12 columns">\n'+
'													<label>Memo</label>\n'+
'													<textarea type="text" name="memo" placeholder="右下にカーソルを合わせると自由に大きさを変えることができます。" required>'+memo+'</textarea>\n'+
'												</div>\n'+
'											</div>\n'+
'											<div class="row">\n'+
'												<div class="small-2 columns">\n'+
'													<div id="checkbox_inline">\n'+
'															<label>Status</label>\n'+
'															<input class="tgl tgl-flip" id="sp_ch_'+id+'" name="st" type="checkbox"  '+st+' >\n'+
'															<label class="tgl-btn" data-tg-off="OFF" data-tg-on="ON" for="sp_ch_'+id+'"></label>\n'+
'													</div>\n'+
'												</div>\n'+
'												<div class="small-4 columns right">\n'+
'														<button type="button" class="button  primary button round button tiny right" onClick="spaceRenew(\'sp_form_'+id+'\');" >更新</button>\n'+
'												</div>\n'+
'									</div>\n'+
'								</form>\n'+
'							</fieldset>\n'+
'					<!-- content2 -->\n';
	return html;
}
function spaceRenew(form_name){
	var form = document.forms[form_name];
	id = form.id.value;
	sp_name = form.sp_n.value;
	sp_id = form.sp_i.value;
	sp_image = form.sp_img.value;
	sp_memo = form.memo.value;
	sp_s = form.st.checked;
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=sp_renew&id="+id+"&sp_n="+sp_name+"&sp_id="+sp_id+"&memo="+sp_memo+"&s="+sp_s+"&sp_img="+sp_image+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					alert("追加しました");
					//ページ一覧表示
					document.getElementById("space").innerHTML ="";	
					document.getElementById("category_list").innerHTML ="";	
					document.getElementById("space_list").innerHTML = addSpaceList(ret);
                }
        	}
    });


}
function drow_add_category(space_id){
	html_addcat = '\n'+
'					<!-- content2 -->\n'+
'							<fieldset>\n'+
'								<legend>新規(カテゴリー)</legend>\n'+
'								<form class=\"custom\" ACTION=\"ajax.cgi\" name="cat_new_form" METHOD=\"GET\">\n'+
'									<input  type=\"hidden\" name=\"mode\" value=\"cat_new\"/>\n'+
'									<input  type=\"hidden\" name=\"sp_id\" value=\"'+space_id+'\"/>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"large-4 columns\">\n'+
'											<label>カテゴリ名</label>\n'+
'											<input id=\"url_name\" type=\"text\" name=\"cat_n\" value=\"\" placeholder=\"表示名を入力\" required>\n'+
'										</div>\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>画像リンク</label>\n'+
'											<input id=\"url_img\" type=\"text\" name=\"cat_img\" value=\"\" placeholder=\"画像のURLを入力\" required>\n'+
'										</div>\n'+
'									</div>					\n'+
'									<div class=\"row\">			\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>Memo</label>\n'+
'											<textarea type=\"text\" name=\"memo\"  placeholder=\"右下にカーソルを合わせると自由に大きさを変えることができます。\" required></textarea>\n'+
'										</div>\n'+
'									</div>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"small-2 columns\">\n'+
'											<div id=\"checkbox_inline\">\n'+
'													<label>Status</label>\n'+
'													<input class=\"tgl tgl-flip\" id=\"new\" name=\"st\" type=\"checkbox\" >\n'+
'													<label class=\"tgl-btn\" data-tg-off=\"OFF\" data-tg-on=\"ON\" for=\"new\"></label>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"small-2 columns right\">\n'+
'												<button type="button" class="button highlight-dark button round button tiny right" onClick="create_category(\'cat_new_form\');" >更新</button>\n'+
'										</div>					\n'+
'									</div>					\n'+
'								</form>\n'+
'							</fieldset>\n'+
'					<!-- content2 -->\n';
return html_addcat;
}
function create_category(form_name){
	var form = document.forms[form_name];
	cat_name = form.cat_n.value;
	cat_image = form.cat_img.value;
	cat_memo = form.memo.value;
	cat_s = form.st.checked;
	sp_id = form.sp_id.value;

	var checkboxElements = document.forms['pg_select_form'];
	var id ="";
	for (var i = 0, len = checkboxElements.length; i< len; i++){
			if(checkboxElements[i].checked){
				//ページ一覧の中身が１つの場合要素へのアクセスができなる
				id += checkboxElements[i].value+",";
			}
	}
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=cat_new&cat_n="+cat_name+"&memo="+cat_memo+"&s="+cat_s+"&cat_img="+cat_image+"&slct_id="+id+"&sp_i="+sp_id+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					alert("追加しました");
					//ページ一覧表示
					document.getElementById("space").innerHTML ="";	
					document.getElementById("space_list").innerHTML = addSpaceList(ret);
					document.getElementById("category").innerHTML ="";	
					//document.getElementById("category").innerHTML = drow_category_content(ret);
					document.getElementById("category_list").innerHTML ="";	
					document.getElementById("page_list").innerHTML = " <h6>スペースとカテゴリーを選択して下さい</h6>";	
                }
        	}
    });


}
function AddPage(name){
	document.getElementById("page").innerHTML = "";	
	target = document.getElementById("addpage");	
	target.innerHTML = '\n'+
'					<!-- content2 -->\n'+
'							<fieldset>\n'+
'								<legend>'+name+'</legend>\n'+
'								<form class=\"custom\" ACTION=\"ajax.cgi\" METHOD=\"GET\" name="form_add_page">\n'+
'									<input  type=\"hidden\" name=\"mode\" value=\"pg_new\"/>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"large-4 columns\">\n'+
'											<label>表示名</label>\n'+
'											<input id=\"url_txt\" type=\"text\" name=\"pg_n\" value=\"'+name+'\" placeholder=\"表示名を入力\" required>\n'+
'										</div>\n'+
'										<div class=\"large-8 columns\">\n'+
'											<div class=\"row collapse\">\n'+
'												<label>管理ID</label>\n'+
'                   								<div class=\"small-12 columns\">\n'+
'                   								   <span class=\"prefix\">フォルダ名&#061; '+name+'</span>\n'+
'														<input  type=\"hidden\" name=\"pg_i\" value=\"'+name+'\"/>\n'+
'                   								</div>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>画像リンク</label>\n'+
'											<input id=\"url_img\" type=\"text\" name=\"pg_img\" value=\"\" placeholder=\"画像URLを入力\" >\n'+
'										</div>\n'+
'									</div>					\n'+
'									<div class=\"row\">			\n'+
'										<div class=\"large-12 columns\">\n'+
'											<label>Memo</label>\n'+
'											<textarea type=\"text\" name=\"memo\"  placeholder=\"右下にカーソルを合わせると自由に大きさを変えることができます。\" ></textarea>\n'+
'										</div>\n'+
'									</div>\n'+
'									<div class=\"row\">\n'+
'										<div class=\"small-2 columns\">\n'+
'											<div id=\"checkbox_inline\">\n'+
'													<label>Status</label>\n'+
'													<input class=\"tgl tgl-flip\" id=\"new\" name=\"st\" type=\"checkbox\" >\n'+
'													<label class=\"tgl-btn\" data-tg-off=\"OFF\" data-tg-on=\"ON\" for=\"new\"></label>\n'+
'											</div>\n'+
'										</div>\n'+
'										<div class=\"small-4 columns right\">\n'+
'												<!--p><input  type=\"submit\" name=\"submit\" class=\"button highlight-dark button round button tiny right\"  value=\"保存\" /></p-->\n'+
'														<button type="button" class="button  primary button round button tiny right" onClick="create_page(\'form_add_page\');" >更新</button>\n'+
'										</div>					\n'+
'									</div>					\n'+
'								</form>\n'+
'							</fieldset>\n'+
'					<!-- content2 -->\n';
}
function create_page(form_name){
	var form = document.forms[form_name];
	pg_name = form.pg_n.value;
	pg_id = form.pg_i.value;
	pg_image = form.pg_img.value;
	pg_memo = form.memo.value;
	pg_s = form.st.checked;
	$.ajax({
            url: "ajax.cgi",
            type: "GET",
            cache: false,
            async: false,
            data: "mode=pg_new&pg_n="+pg_name+"&pg_id="+pg_id+"&memo="+pg_memo+"&s="+pg_s+"&pg_img="+pg_image+"",
            success: function(ret){
                if(ret["ret"] == 'OK'){
					alert("追加しました");
					//ページ一覧表示
					document.getElementById("addpage").innerHTML = "";	
					target = document.getElementById("page");	
					target.innerHTML = addPageList(ret);
                }
        	}
    });

}
