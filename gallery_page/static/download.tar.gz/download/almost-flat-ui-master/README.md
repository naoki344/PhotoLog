Almost Flat UI
=======

When using the markup from the demo page, please update the Google Analytics Code to that of your own.

Almost Flat UI is licensed under a MIT License. It uses Foundation Framework and is heavily inspired from Flat UI Free by designmodo.

You are allowed to use these elements anywhere you want.

## Links:

+ [Demo page](http://websymphony.net/almost-flat-ui/)

## Author
**Amit Gaur**

+ [http://websymphony.net](http://websymphony.net)
+ [http://twitter.com/websymphony](http://twitter.com/websymphony)
