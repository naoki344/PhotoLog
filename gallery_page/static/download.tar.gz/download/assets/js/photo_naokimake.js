var page = 0;
var photo;
function reload(move){
	$.ajax({
		url: "ajax.cgi",
		type: "GET",
		cache: false,
		async: false,
		data: "mode=photo&page="+move,
		success: function(data){
			if(data["ret"] == 'OK'){
				photo = data["photo"];
				draw();
			}
		}
	});
}
function draw(){
	var html = '';
	for(i=0; i<photo.length; i++){
		html += '<figure data-role="none">';
		html += '<a  href="'+photo[i]["n"]+'" data-size="'+photo[i]["x"]+'x'+photo[i]["y"]+'">';
		html += '<img  src="'+photo[i]["n"]+'">';
		html += '</a>';
		html += '</figure>';


	}
	document.getElementById('photo').innerHTML = html;
	initPhotoSwipeFromDOM('#photo');
}
function view(n){
	window.open('photo/'+photo[n]["n"]);
}


$(document).on('pagebeforeshow', '#photo', function(){   
    var myPhotoSwipe = $(".gallery li a").photoSwipe({
        jQueryMobile: true,
        loop: false,
        enableMouseWheel: false,
        enableKeyboard: false
    });

    myPhotoSwipe.show(0);      
});

window.paceOptions = {
	restartOnPushState: false
    }
$(document).ready(function(){
	$('.bxslider').bxSlider();
})

