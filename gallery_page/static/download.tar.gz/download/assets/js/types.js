/* ふりがなチェック */
function furiganaCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^ぁ-ん　\s]+/ ) ) {
      show_alert(id,"ふりがなは「ひらがな」で入力して下さい。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
/* 半角英字チェック */
function alphaCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^A-Za-z\s.-]+/ ) ) {
      show_alert(id,"半角英文字のみで入力して下さい。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
/* 半角英数チェック */
function alnumCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^A-Za-z0-9]+/ ) ) {
      show_alert(id,"半角英数字のみで入力して下さい。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
/* 半角数字チェック */
function digitCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^0-9]+/ ) ) {
      show_alert(id,"半角数字のみで入力して下さい。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
/* 半角数字とマイナスチェック */
function digitsCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^0-9\-]+/ ) ) {
      show_alert(id,"半角数字のみで入力して下さい。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
/* メールアドレス */
function digitmCheck(arg,n) {
   var id=arg.id.substr(2,3);
   if( n != 0 && arg.value == ""){
      show_alert(id,"必須項目です。");
      return 1;
   }
   if( arg.value.match( /[^A-Za-z0-9_\.\-\@]+/ ) ) {
      show_alert(id,"半角英数字で入力して下さい。");
      return 1;
   } else if(arg.value.indexOf("@") < 0 || arg.value.indexOf("@") != arg.value.lastIndexOf("@")){
      show_alert(id,"正しいメールアドレスを入力してください。");
      return 1;
   } else {
      show_alert(id,"");
   }
   return 0;
}
