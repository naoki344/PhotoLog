/** Toggle buttons
 * @mallendeo
 */