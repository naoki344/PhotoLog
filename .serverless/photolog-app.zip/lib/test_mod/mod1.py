#/usr/bin/python3

class touch():

  def __init__( self, num):
    self.auth = num
    print (self.auth)
