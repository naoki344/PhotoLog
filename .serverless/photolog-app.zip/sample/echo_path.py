import sys
import pprint

pprint.pprint(sys.path)
