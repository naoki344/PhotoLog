export const FolderModel = {
  folder_id: '',
  author_id: '',
  name: '',
  description: '',
  register_date: '',
  last_update_date: '',
  release_status: '',
  share_range: '',
  share_url: '',
  thumbnail_url: '',
  delete_status: ''
};

export const FolderFromModel = {
  folder_id: '',
  author_id: '',
  name: '',
  description: '',
  register_date: '',
  last_update_date: '',
  release_status: '',
  share_range: '',
  share_url: '',
  thumbnail_url: '',
  delete_status: ''
};
